<?php

include("header.php");
include("navbar.php");
?>
<center>
    <img src="images/gurl.gif" alt="home" style="width: 500px">
</center>
<center>
  <img src="images/blackver.png" alt="home" style="width: 200px; margin-top: 100px;">
</center>
