<?php 

$conn = mysqli_connect("localhost", "root", "", "dan_db");

?>

dannb